export { default } from './AssetRequirement';
