export { default } from './Tabs';
