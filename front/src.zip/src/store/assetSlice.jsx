// src/store/assetSlice.jsx
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../config/api.js";


const getErrorMessage = (err, fallbackMessage) => {
    return err?.response?.data?.detail || fallbackMessage || "Request failed";
};

/* ======================
   Async Thunks
   ====================== */

// Get all assets
export const fetchAssets = createAsyncThunk(
    "assets/fetchAll",
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get("/api/assets/");
            return response.data;
        } catch (err) {
            return rejectWithValue(getErrorMessage(err, "Failed to fetch assets"));
        }
    }
);

// Get single asset
export const fetchAsset = createAsyncThunk(
    "assets/fetchOne",
    async (assetId, { rejectWithValue }) => {
        try {
            const response = await api.get(`/api/assets/${assetId}`);
            return response.data;
        } catch (err) {
            return rejectWithValue(getErrorMessage(err, "Failed to fetch asset"));
        }
    }
);

// Create asset
export const createAsset = createAsyncThunk(
    "assets/create",
    async (assetData, { rejectWithValue }) => {
        try {
            const response = await api.post("/api/assets/", assetData);
            return response.data;
        } catch (err) {
            return rejectWithValue(getErrorMessage(err, "Failed to create asset"));
        }
    }
);

// Update asset
export const updateAsset = createAsyncThunk(
    "assets/update",
    async ({ assetId, assetData }, { rejectWithValue }) => {
        try {
            const response = await api.put(`/api/assets/${assetId}`, assetData);
            return response.data;
        } catch (err) {
            return rejectWithValue(getErrorMessage(err, "Failed to update asset"));
        }
    }
);

// Delete asset
export const deleteAsset = createAsyncThunk(
    "assets/delete",
    async (assetId, { rejectWithValue }) => {
        try {
            await api.delete(`/api/assets/${assetId}`);
            return assetId; // برای حذف از state
        } catch (err) {
            return rejectWithValue(getErrorMessage(err, "Failed to delete asset"));
        }
    }
);

/* ======================
   Slice
   ====================== */

const initialState = {
    assets: [],
    selectedAsset: null,
    isLoading: false,
    error: null,
    successMessage: null,
};

const assetSlice = createSlice({
    name: "assets",
    initialState,
    reducers: {
        clearMessages: (state) => {
            state.error = null;
            state.successMessage = null;
        },
        clearSelectedAsset: (state) => {
            state.selectedAsset = null;
        },
    },
    extraReducers: (builder) => {
        builder
            /* ---- Fetch all ---- */
            .addCase(fetchAssets.pending, (state) => {
                state.isLoading = true;
                state.error = null;
                state.successMessage = null;
            })
            .addCase(fetchAssets.fulfilled, (state, action) => {
                state.isLoading = false;
                state.assets = Array.isArray(action.payload) ? action.payload : [];
            })
            .addCase(fetchAssets.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            })

            /* ---- Fetch one ---- */
            .addCase(fetchAsset.pending, (state) => {
                state.isLoading = true;
                state.error = null;
            })
            .addCase(fetchAsset.fulfilled, (state, action) => {
                state.isLoading = false;
                state.selectedAsset = action.payload;
            })
            .addCase(fetchAsset.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            })

            /* ---- Create ---- */
            .addCase(createAsset.pending, (state) => {
                state.isLoading = true;
                state.error = null;
                state.successMessage = null;
            })
            .addCase(createAsset.fulfilled, (state, action) => {
                state.isLoading = false;
                state.assets.push(action.payload);
                state.successMessage = "Asset created successfully!";
            })
            .addCase(createAsset.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            })

            /* ---- Update ---- */
            .addCase(updateAsset.pending, (state) => {
                state.isLoading = true;
                state.error = null;
                state.successMessage = null;
            })
            .addCase(updateAsset.fulfilled, (state, action) => {
                state.isLoading = false;
                const updated = action.payload;
                const index = state.assets.findIndex((a) => a.id === updated.id);
                if (index !== -1) {
                    state.assets[index] = updated;
                }
                state.successMessage = "Asset updated successfully!";
            })
            .addCase(updateAsset.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            })

            /* ---- Delete ---- */
            .addCase(deleteAsset.pending, (state) => {
                state.isLoading = true;
                state.error = null;
                state.successMessage = null;
            })
            .addCase(deleteAsset.fulfilled, (state, action) => {
                state.isLoading = false;
                state.assets = state.assets.filter((a) => a.id !== action.payload);
                state.successMessage = "Asset deleted successfully!";
            })
            .addCase(deleteAsset.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            });
    },
});

export const { clearMessages, clearSelectedAsset } = assetSlice.actions;
export default assetSlice.reducer;
